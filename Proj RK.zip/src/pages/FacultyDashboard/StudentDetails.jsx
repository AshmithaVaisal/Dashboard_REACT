import React, { useContext, useState } from "react";
import { useNavigate } from "react-router-dom";
import { StudentContext } from "../../context/StudentContext";
import "../../styles/studentDetails.css"; // Assuming you have a CSS file for styling

const StudentDetails = () => {
  const { students, setStudents } = useContext(StudentContext);
  const navigate = useNavigate();

  // Function to delete a student
  const handleDelete = (index) => {
    const confirmDelete = window.confirm("Are you sure you want to delete this student?");
    if (confirmDelete) {
      const updatedStudents = students.filter((_, i) => i !== index);
      setStudents(updatedStudents);
      alert("Student deleted successfully!");
    }
  };

  // Function to navigate to the update page with student data
  const handleUpdate = (student, index) => {
    navigate("/faculty/update-student", { state: { student, index } });
  };

  return (
    <div className="student-details">
      <h2>Student Details</h2>
      <table>
        <thead>
          <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>DOB</th>
            <th>Gender</th>
            <th>Blood Group</th>
            <th>Contact</th>
            <th>Address</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {students.map((student, index) => (
            <tr key={index}>
              <td>{student.firstName}</td>
              <td>{student.lastName}</td>
              <td>{student.dob}</td>
              <td>{student.gender}</td>
              <td>{student.bloodGroup}</td>
              <td>{student.contact}</td>
              <td>{student.address}</td>
              <td>
                <button onClick={() => handleUpdate(student, index)}>Update</button>
                <button onClick={() => handleDelete(index)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default StudentDetails;
