import React, { useState, useContext } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { StudentContext } from "../../context/StudentContext";
import "../../styles/updateStudent.css"; // Add CSS for styling

const UpdateStudent = () => {
  const location = useLocation();
  const { student, index } = location.state;
  const { students, setStudents } = useContext(StudentContext);
  const navigate = useNavigate();

  const [formData, setFormData] = useState(student);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSave = () => {
    const updatedStudents = [...students];
    updatedStudents[index] = formData;
    setStudents(updatedStudents);
    alert("Student updated successfully!");
    navigate("/faculty/student-details");
  };

  const handleClose = () => {
    navigate("/faculty/student-details");
  };

  return (
    <div className="update-student">
      <h2>Update Student</h2>
      <form>
        <label>
          First Name:
          <input
            type="text"
            name="firstName"
            value={formData.firstName}
            onChange={handleInputChange}
          />
        </label>
        <label>
          Last Name:
          <input
            type="text"
            name="lastName"
            value={formData.lastName}
            onChange={handleInputChange}
          />
        </label>
        <label>
          Date of Birth:
          <input
            type="date"
            name="dob"
            value={formData.dob}
            onChange={handleInputChange}
          />
        </label>
        <label>
          Gender:
          <select
            name="gender"
            value={formData.gender}
            onChange={handleInputChange}
          >
            <option value="Male">Male</option>
            <option value="Female">Female</option>
          </select>
        </label>
        <label>
          Blood Group:
          <input
            type="text"
            name="bloodGroup"
            value={formData.bloodGroup}
            onChange={handleInputChange}
          />
        </label>
        <label>
          Contact:
          <input
            type="text"
            name="contact"
            value={formData.contact}
            onChange={handleInputChange}
          />
        </label>
        <label>
          Address:
          <textarea
            name="address"
            value={formData.address}
            onChange={handleInputChange}
          ></textarea>
        </label>
        <div className="actions">
          <button type="button" onClick={handleSave}>
            Save
          </button>
          <button type="button" onClick={handleClose}>
            Close
          </button>
        </div>
      </form>
    </div>
  );
};

export default UpdateStudent;
