import React, { createContext, useState } from "react";

// Create the context
export const StudentContext = createContext();

// Context provider component
export const StudentProvider = ({ children }) => {
  const [students, setStudents] = useState([]);

  return (
    <StudentContext.Provider value={{ students, setStudents }}>
      {children}
    </StudentContext.Provider>
  );
};